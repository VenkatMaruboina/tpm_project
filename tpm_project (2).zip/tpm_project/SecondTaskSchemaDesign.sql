-- =========================
-- DATABASE: TPM_DB
-- =========================

-- =========================
-- PARTITION SETUP
-- =========================
CREATE PARTITION FUNCTION pf_OrderDate (DATETIME2)
AS RANGE RIGHT FOR VALUES (
    '2023-01-01',
    '2024-01-01',
    '2025-01-01'
);

CREATE PARTITION SCHEME ps_OrderDate
AS PARTITION pf_OrderDate
ALL TO ([PRIMARY]);

-- =========================
-- CUSTOMERS
-- =========================
CREATE TABLE Customers (
    CustomerID BIGINT IDENTITY(1,1) PRIMARY KEY,
    Customer_Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) UNIQUE,
    MobileNumber NVARCHAR(15),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT GETDATE()
);

CREATE UNIQUE INDEX IDX_Customers_Email ON Customers(Email);

-- =========================
-- PRODUCTS
-- =========================
CREATE TABLE Products (
    ProductID BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductName NVARCHAR(150) NOT NULL,
    Product_Category NVARCHAR(100)
);

CREATE INDEX IDX_Products_Category 
ON Products(Product_Category);

-- =========================
-- PRODUCT VARIANTS
-- =========================
CREATE TABLE Product_Variants (
    ProductVariantID BIGINT IDENTITY(1,1) PRIMARY KEY,
    ProductID BIGINT NOT NULL,
    Variant_Price DECIMAL(12,2),
    Variant_Quantity INT,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

CREATE INDEX IDX_ProductVariants_ProductID 
ON Product_Variants(ProductID);

-- =========================
-- ORDERS (PARTITIONED)
-- =========================
CREATE TABLE Orders (
    OrderID BIGINT IDENTITY(1,1),
    CustomerID BIGINT NOT NULL,
    OrderDate DATETIME2 NOT NULL,
    Status NVARCHAR(50),
    TotalAmount DECIMAL(12,2),

    CONSTRAINT PK_Orders PRIMARY KEY (OrderID, OrderDate),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
)
ON ps_OrderDate(OrderDate);

CREATE INDEX IDX_Orders_CustomerID_OrderDate
ON Orders(CustomerID, OrderDate)
ON ps_OrderDate(OrderDate);

CREATE INDEX IDX_Orders_OrderDate
ON Orders(OrderDate)
ON ps_OrderDate(OrderDate);

-- =========================
-- ORDER ITEMS
-- =========================
CREATE TABLE OrderItems (
    OrderItemID BIGINT IDENTITY(1,1) PRIMARY KEY,
    OrderID BIGINT NOT NULL,
    ProductVariantID BIGINT NOT NULL,
    Quantity INT NOT NULL,
    PriceAtPurchase DECIMAL(12,2),

    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductVariantID) REFERENCES Product_Variants(ProductVariantID)
);

CREATE INDEX IDX_OrderItems_OrderID ON OrderItems(OrderID);
CREATE INDEX IDX_OrderItems_ProductVariantID ON OrderItems(ProductVariantID);

-- COLUMNSTORE (Analytics Optimization)
CREATE CLUSTERED COLUMNSTORE INDEX CCI_OrderItems
ON OrderItems;

-- =========================
-- PAYMENT MODULE
-- =========================
CREATE TABLE Payment_Methods (
    PaymentMethodID BIGINT IDENTITY(1,1) PRIMARY KEY,
    Method_Name NVARCHAR(100)
);

CREATE TABLE Payment_Status (
    PaymentStatusID BIGINT IDENTITY(1,1) PRIMARY KEY,
    Status_Name NVARCHAR(50)
);

CREATE TABLE Payments (
    PaymentID BIGINT IDENTITY(1,1) PRIMARY KEY,
    OrderID BIGINT NOT NULL,
    PaymentMethodID BIGINT,
    PaymentStatusID BIGINT,
    Amount DECIMAL(12,2),
    PaymentDate DATETIME2,

    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (PaymentMethodID) REFERENCES Payment_Methods(PaymentMethodID),
    FOREIGN KEY (PaymentStatusID) REFERENCES Payment_Status(PaymentStatusID)
);

CREATE INDEX IDX_Payments_OrderID ON Payments(OrderID);
CREATE INDEX IDX_Payments_Status ON Payments(PaymentStatusID);

-- =========================
-- SHIPPING
-- =========================
CREATE TABLE Shipping (
    ShippingID BIGINT IDENTITY(1,1) PRIMARY KEY,
    Shipping_Name NVARCHAR(100)
);

CREATE TABLE Order_Shipping (
    OrderShippingID BIGINT IDENTITY(1,1) PRIMARY KEY,
    OrderID BIGINT NOT NULL,
    ShippingID BIGINT NOT NULL,

    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ShippingID) REFERENCES Shipping(ShippingID)
);

CREATE INDEX IDX_OrderShipping_OrderID ON Order_Shipping(OrderID);

CREATE TABLE Shipping_Addresses (
    ShippingAddressID BIGINT IDENTITY(1,1) PRIMARY KEY,
    OrderID BIGINT NOT NULL,
    Address NVARCHAR(255),

    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

CREATE INDEX IDX_ShippingAddress_OrderID ON Shipping_Addresses(OrderID);

-- =========================
-- INVOICE
-- =========================
CREATE TABLE Payment_Invoice (
    InvoiceID BIGINT IDENTITY(1,1) PRIMARY KEY,
    PaymentID BIGINT NOT NULL,

    FOREIGN KEY (PaymentID) REFERENCES Payments(PaymentID)
);

-- Customers
INSERT INTO Customers (Customer_Name, Email)
VALUES 
('Venkat', 'venkat@gmail.com'),
('Ravi', 'ravi@gmail.com'),
('Suresh', 'suresh@gmail.com'),
('Anil', 'anil@gmail.com'),
('Kiran', 'kiran@gmail.com');

-- Products
INSERT INTO Products (ProductName)
VALUES ('Laptop'), ('Phone'), ('Tablet');

-- Product Variants
INSERT INTO Product_Variants (ProductID, Variant_Price, Variant_Quantity)
VALUES 
(1, 50000, 10),
(2, 20000, 20),
(3, 15000, 15);

-- Orders
INSERT INTO Orders (CustomerID, OrderDate, Status, TotalAmount)
VALUES 
(1, GETDATE(), 'Completed', 50000),
(1, DATEADD(DAY, -5, GETDATE()), 'Completed', 20000),
(2, DATEADD(DAY, -10, GETDATE()), 'Completed', 40000),
(3, DATEADD(DAY, -40, GETDATE()), 'Completed', 15000),
(1, DATEADD(DAY, -2, GETDATE()), 'Completed', 30000);

-- Order Items (IMPORTANT: uses ProductVariantID)
INSERT INTO OrderItems (OrderID, ProductVariantID, Quantity, PriceAtPurchase)
VALUES 
(1, 1, 1, 50000),
(2, 2, 1, 20000),
(3, 2, 2, 20000),
(4, 3, 1, 15000),
(5, 1, 1, 30000);

--Query 1: Top 3 Customers by Order Count (CORRECT FINAL VERSION)
SELECT TOP 3
    c.CustomerID,
    c.Customer_Name,
    COUNT(o.OrderID) AS TotalOrders
FROM Customers c
JOIN Orders o 
    ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerID, c.Customer_Name
ORDER BY TotalOrders DESC;

--Query 2: Recent Orders (CORRECT FINAL VERSION)
SELECT 
    o.OrderID,
    o.CustomerID,
    o.OrderDate,
    o.Status,
    o.TotalAmount
FROM Orders o
WHERE o.OrderDate >= DATEADD(DAY, -30, GETDATE());

--Query 3: Revenue per Product (CORRECT FINAL VERSION)
SELECT 
    p.ProductID,
    p.ProductName,
    SUM(oi.Quantity * oi.PriceAtPurchase) AS TotalRevenue
FROM Products p
JOIN Product_Variants pv 
    ON p.ProductID = pv.ProductID
JOIN OrderItems oi 
    ON pv.ProductVariantID = oi.ProductVariantID
GROUP BY p.ProductID, p.ProductName
ORDER BY TotalRevenue DESC;