# TPM Assessment Project (With Swagger)

## Run API (with MS SQL Server)

1. **Install dependencies**
   - `pip install -r requirements.txt`

2. **Set `DATABASE_URL` to your SQL Server**
   - Example (Windows, MS SQL with ODBC Driver 18)
     - PowerShell:  
       ` $env:DATABASE_URL = "mssql+pyodbc://username:password@localhost/YourDatabase?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=no"`
     - CMD:  
       ` set DATABASE_URL=mssql+pyodbc://username:password@localhost/YourDatabase?driver=ODBC+Driver+18+for+SQL+Server^&Encrypt=no`

3. **Run the app**
   - `python app.py`

## Swagger UI
http://127.0.0.1:5000/apidocs/

Use header:
x-api-key: mysecureapikey123

## Large dataset notes (100M+ rows)
- Use **MS SQL Server** via `DATABASE_URL` (SQLite is not suitable for 100M+ rows/concurrency).
- Typical SQL Server URL (Windows, local dev):
  - `DATABASE_URL=mssql+pyodbc://username:password@localhost/YourDatabase?driver=ODBC+Driver+18+for+SQL+Server&Encrypt=no`
- `GET /records` uses **keyset pagination**:
  - `GET /records?limit=100` → first page
  - `GET /records?limit=100&after_id=<last_id_from_previous_page>` → next page
