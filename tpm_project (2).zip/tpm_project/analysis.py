import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data.csv")
df.dropna(inplace=True)
df['Timestamp'] = pd.to_datetime(df['Timestamp'])

popular = df['Product Category'].value_counts()
print(popular)

purchases = len(df[df['Action'] == 'purchased'])
conversion_rate = purchases / len(df)
print("Conversion Rate:", conversion_rate)
