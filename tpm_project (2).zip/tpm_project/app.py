import os

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flasgger import Swagger
from auth import require_api_key

app = Flask(__name__)
database_url = os.getenv("DATABASE_URL")
if not database_url:
    raise RuntimeError(
        "DATABASE_URL is not set. Please set it to your MS SQL connection string, "
        "for example: "
        "'mssql+pyodbc://user:password@server/database?driver=ODBC+Driver+18+for+SQL+Server'"
    )

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Helps when using a real DB (e.g. Postgres/MySQL) under load.
# Note: SQLite ignores most pooling options.
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_pre_ping": True,
    "pool_recycle": int(os.getenv("SQLALCHEMY_POOL_RECYCLE_SECONDS", "1800")),
}

db = SQLAlchemy(app)
swagger = Swagger(app)

class Record(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    status = db.Column(db.String(50), index=True)

    __table_args__ = (
        # Supports efficient "status + id" keyset pagination
        db.Index("ix_records_status_id", "status", "id"),
    )

@app.before_first_request
def create_tables():
    if os.getenv("AUTO_CREATE_TABLES", "1") == "1":
        db.create_all()

@app.route('/records', methods=['POST'])
@require_api_key
def add_record():
    """
    Add a new record
    ---
    tags:
      - Records
    parameters:
      - in: body
        name: body
        schema:
          type: object
          required:
            - name
            - status
          properties:
            name:
              type: string
            status:
              type: string
    responses:
      201:
        description: Record added successfully
    """
    data = request.json
    record = Record(name=data['name'], status=data['status'])
    db.session.add(record)
    db.session.commit()
    return jsonify({"message": "Record added"}), 201

@app.route('/records', methods=['GET'])
@require_api_key
def get_records():
    """
    List records with keyset pagination (suitable for very large tables)
    ---
    tags:
      - Records
    parameters:
      - name: status
        in: query
        type: string
        required: false
      - name: after_id
        in: query
        type: integer
        required: false
        description: Return records with id greater than this value (keyset cursor)
      - name: limit
        in: query
        type: integer
        required: false
        description: Max rows to return (default 100, max 1000)
    responses:
      200:
        description: Paginated list of records
    """
    status = request.args.get('status')
    after_id = request.args.get("after_id", type=int)
    limit = request.args.get("limit", default=100, type=int)
    limit = max(1, min(limit, 1000))

    q = Record.query
    if status:
        q = q.filter(Record.status == status)
    if after_id is not None:
        q = q.filter(Record.id > after_id)

    # Keyset pagination: stable and fast at large row counts.
    records = q.order_by(Record.id.asc()).limit(limit + 1).all()

    has_more = len(records) > limit
    records = records[:limit]
    next_after_id = records[-1].id if (has_more and records) else None

    return jsonify(
        {
            "items": [{"id": r.id, "name": r.name, "status": r.status} for r in records],
            "next_after_id": next_after_id,
            "limit": limit,
        }
    )

@app.route('/records/<int:id>', methods=['PUT'])
@require_api_key
def update_record(id):
    """
    Update a record
    ---
    tags:
      - Records
    parameters:
      - name: id
        in: path
        type: integer
        required: true
      - in: body
        name: body
        schema:
          type: object
          properties:
            name:
              type: string
            status:
              type: string
    responses:
      200:
        description: Record updated
    """
    record = Record.query.get_or_404(id)
    data = request.json
    record.name = data.get('name', record.name)
    record.status = data.get('status', record.status)
    db.session.commit()
    return jsonify({"message": "Updated successfully"})

@app.route('/records/<int:id>', methods=['DELETE'])
@require_api_key
def delete_record(id):
    """
    Delete a record
    ---
    tags:
      - Records
    parameters:
      - name: id
        in: path
        type: integer
        required: true
    responses:
      200:
        description: Record deleted
    """
    record = Record.query.get_or_404(id)
    db.session.delete(record)
    db.session.commit()
    return jsonify({"message": "Deleted successfully"})

if __name__ == '__main__':
    app.run(debug=True)
